import express from 'express';
import { cdoctores, loginDoctor, perfil } from '../controllers/doctorController.js';

const router = express.Router();

router.post('/register', cdoctores);
router.get('/login', loginDoctor);
router.get('/perfil', perfil);

export default router;