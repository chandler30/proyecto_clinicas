import Doctor from '../models/Doctor.js';
import bcrypt from 'bcrypt';

const cdoctores = async (req, res) => {
  try {
    console.log(req.body);
    const { email, password, confirmPassword, nombre, Celuar } = req.body;

    // Comprobar si el correo electrónico ya está registrado
    let doctor = await Doctor.findOne({ email });
    if (doctor) {
      return res.status(400).json({ mensaje: 'El usuario ya está registrado' });
    }

    // Comprobar si las contraseñas coinciden
    if (password !== confirmPassword) {
      return res.status(400).json({ mensaje: 'Las contraseñas no coinciden' });
    }

    // Hashear la contraseña y crear una nueva instancia de Doctor
    const hashedPassword = bcrypt.hashSync(password, 10);
    doctor = new Doctor({ email, password: hashedPassword, nombre, Celuar });
    await doctor.save();

    res.json({ mensaje: 'Registrando un nuevo doctor' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Hubo un error' });
  }
};

const loginDoctor = (req, res) => {
  res.send('Has ingresado a la ruta de inicio de sesión');
};

const perfil = (req, res) => {
  res.json({mensaje:"Has ingresado a la ruta de perfil de usuario"});
};

export {
    cdoctores,loginDoctor,perfil
}

