import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const doctorSchema = new mongoose.Schema({

    nombre: {
        type: String,
        required: true,
        trim: true
    },

    password : {
        type: String,
        required: true
    },

    email : {
        type: String,
        required: true,
        unique: true,
        trim: true
    },

    Celuar : {
        type: String,
        default: null,
        trim: true
    },

    token : {
        type: String,
    },

    confirmado : {
        type: Boolean,
        default: false
    },
});

doctorSchema.methods.setPassword = function(password) {
    this.password = bcrypt.hashSync(password, 10);
};

doctorSchema.methods.checkPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

const Doctor = mongoose.model('Doctor', doctorSchema);

export default Doctor;